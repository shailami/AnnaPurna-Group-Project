package com.cg.annapurna.OrderServiceWebsite.OrderServiceWebsite;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OrderServiceWebsiteApplication {

	public static void main(String[] args) {
		SpringApplication.run(OrderServiceWebsiteApplication.class, args);
	}

}

